<!doctype html>
<html lang="ru">
<head>
    <title>Document123</title>
</head>
<body>



<?php
require_once 'menu.php';
?>

<meta http-equiv="Refresh" content="2; href=menu.>

</body>
</html>